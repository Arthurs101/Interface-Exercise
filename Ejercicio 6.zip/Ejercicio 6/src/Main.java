/******************************************************************
Main.java
Autor: Adrian Fulladolsa Palma y Arturo Heberto Argueta Avila
Última modificación: 2021-11-09
Clase que ejecuta el programa.
******************************************************************/
public class Main {
    public static void main(String args[]) {
        Controlador c = new  Controlador();
        c.Start();
    }
}
